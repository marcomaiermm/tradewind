new data must not replace existing price cache
